from pydantic import BaseModel
from typing import Optional
from datetime import date


class ObjetoDTO(BaseModel):
    id: int
    nombre: str
    descripcion: str 
    fecha: date
    lugar: str
    filename: Optional[str] = None
    user_id: str

    model_config = {
        "from_attributes": True
    }


class CreateObjetoDTO(BaseModel):
    nombre: str
    descripcion: str 
    fecha: date
    lugar: str
    filename: Optional[str] = None
    user_id: str