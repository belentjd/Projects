import httpx
from aiocache import cached, Cache
from aiocache.serializers import JsonSerializer


@cached(ttl=600, cache=Cache.MEMORY, serializer=JsonSerializer()) # TTL = 600 segundos = 10 minutos
async def get_location(lugar: str):
    url = "https://nominatim.openstreetmap.org/search"

    params = {
        "q": lugar,
        "format": "json",
        "limit": 1,
        "countrycodes": "es"
    }

    headers = {
        "User-Agent": "mi-app-objetos"
    }

    async with httpx.AsyncClient() as client:
        response = await client.get(url, params=params, headers=headers)
        if response.status_code == 200:
            data= response.json()

    if data:
        return {
            "lat": data[0]["lat"],
            "lon": data[0]["lon"],
            "display_name": data[0]["display_name"]
        }

    return {}