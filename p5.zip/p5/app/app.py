from flask import Flask, render_template, send_from_directory
from methodOverride import MethodOverrideMiddleware
import os
from blueprints.objetos import objetos_bp
from blueprints.usuarios import usuarios_bp
from blueprints.auth.auth import auth_bp
from sqlalchemy_utils import create_database, database_exists
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from database import db
from models import Objeto, Usuario
import click
from flask.cli import with_appcontext
from models.seeders.fillobjeto import seedObjeto
from models.seeders.fillusuario import seedUsuario
from api import api_v1
from flasgger import Swagger
import logging
from logger import logger
from opentelemetry.instrumentation.flask import FlaskInstrumentor
from flask_cors import CORS



app = Flask(__name__, static_folder='public', template_folder='templates')

app.register_blueprint(objetos_bp)
app.register_blueprint(usuarios_bp)
app.register_blueprint(auth_bp, url_prefix="/auth")
app.wsgi_app = MethodOverrideMiddleware(app.wsgi_app)

##### Configure flash key
app.secret_key = '1234'

##### Configure file uploads
app.config['UPLOAD_FOLDER'] = 'app/assets/images'
app.config['ALLOWED_EXTENSIONS'] = {'png', 'jpg', 'jpeg'}

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/about")
def about():
    return render_template("about.html")

@app.errorhandler(404)
def error_404(error):
    return render_template("error404.html"), 404

@app.errorhandler(500)
def error_500(error):
    return render_template("error500.html"), 500

@app.route('/assets/<path:filename>')
def media_images(filename):
    return send_from_directory(os.path.join(app.root_path, 'assets'), filename)


##### Configure Database

app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+mysqlconnector://root:kaka2025@localhost/tecw'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

##### Create the database if it doesn't exist
if not database_exists(app.config['SQLALCHEMY_DATABASE_URI']):
    create_database(app.config['SQLALCHEMY_DATABASE_URI'])

##### Migrate models
migrate = Migrate(app, db)

##### Seeders
@click.command(name='seed')
@with_appcontext
def seed():
    admin, user = seedUsuario()
    seedObjeto(admin, user)
    

app.cli.add_command(seed)

app.register_blueprint(api_v1)

##### Configure Swagger
app.config['SWAGGER'] = {
    'title': 'API Objetos',
    'uiversion': 3,
    'openapi': '3.0.3'
}

swagger = Swagger(app, template_file='openapi.yaml')


# 1. Limpiamos y reasignamos el logger de Flask
app.logger.handlers.clear()
for handler in logger.handlers:
    app.logger.addHandler(handler)
app.logger.setLevel(logging.INFO)

# 2. Atrapamos a Werkzeug (el servidor HTTP) para que use nuestra configuración
werkzeug_logger = logging.getLogger('werkzeug')
werkzeug_logger.handlers.clear()
for handler in logger.handlers:
    werkzeug_logger.addHandler(handler)
werkzeug_logger.setLevel(logging.INFO)

# Instrumentación automática de rutas de Flask
FlaskInstrumentor().instrument_app(app) 

CORS(app)