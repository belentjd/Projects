import logging

# 1. Creamos nuestro Custom Logger
logger = logging.getLogger("objetos_api")
logger.setLevel(logging.INFO)

# 2. Definimos los destinos (Handlers)
# StreamHandler imprime en la consola (stdout)
console_handler = logging.StreamHandler()
# FileHandler almacena los logs en un fichero físico
file_handler = logging.FileHandler("api.log", encoding="utf-8")

# 3. Definimos el formato visual (Formatter)
formatter = logging.Formatter(
    '%(asctime)s [%(levelname)s] %(name)s '
    '[trace_id=%(otelTraceID)s span_id=%(otelSpanID)s]: %(message)s',
    defaults={"otelTraceID": "0" * 32, "otelSpanID": "0" * 16}
)
console_handler.setFormatter(formatter)
file_handler.setFormatter(formatter)

# 4. Vinculamos los handlers al logger
logger.addHandler(console_handler)
logger.addHandler(file_handler)