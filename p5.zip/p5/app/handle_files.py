import os
import uuid
from functools import wraps
from flask import request, redirect, current_app, flash
from PIL import Image

# Extensiones y tamaño permitidos
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}
MAX_FILE_SIZE = 5 * 1024 * 1024  # 5MB

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def save_file(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        # Buscamos 'imagen' que es como se llama en el formulario
        file = request.files.get('imagen') 
        kwargs['filename'] = None
        
        if file and file.filename != '':
            # 1. Comprobar extensión
            if not allowed_file(file.filename):
                flash("Error: La extensión no es válida (.png, .jpg, .jpeg)", "error")
                return redirect(request.url)
            
            # 2. Comprobar tamaño (5MB)
            file.seek(0, os.SEEK_END)
            size = file.tell()
            file.seek(0) # Resetear puntero para poder guardar
            if size > MAX_FILE_SIZE:
                flash("Error: El fichero subido supera los 5MB", "error")
                return redirect(request.url)

            # 3. Generar nombre único UUID v4
            extension = file.filename.rsplit('.', 1)[1].lower()
            filename = f"{uuid.uuid4()}.{extension}"
            
            # 4. Guardar en assets/images
            upload_path = os.path.join(current_app.root_path,  'assets', 'images')
            thumb_path = os.path.join(current_app.root_path, 'assets', 'thumbnails')

            os.makedirs(upload_path, exist_ok=True)
            os.makedirs(thumb_path, exist_ok=True)

            file_path = os.path.join(upload_path, filename)
            file.save(file_path)

            # THUMBNAIL 
            thumb_file_path = os.path.join(thumb_path, filename)

            with Image.open(file_path) as img:
                img.thumbnail((150, 150))
                img.save(thumb_file_path)

            kwargs['filename'] = filename
            
        return f(*args, **kwargs)
    return decorated_function

def delete_file(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        objeto = kwargs.get('objeto')
        if objeto and getattr(objeto, 'filename', None):
            image_path = os.path.join(current_app.root_path, 'assets', 'images', objeto.filename)
            thumb_path = os.path.join(current_app.root_path, 'assets', 'thumbnails', objeto.filename)
            if objeto.filename != "default.jpg":
                if os.path.exists(image_path):
                    os.remove(image_path)
                if os.path.exists(thumb_path):
                    os.remove(thumb_path)
        return f(*args, **kwargs)
    return decorated_function