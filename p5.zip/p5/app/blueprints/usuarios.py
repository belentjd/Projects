from flask import Blueprint, render_template, request, redirect, url_for, abort
from functools import wraps
from models import Usuario  
from database import db
from werkzeug.security import generate_password_hash
from access_control import check_session, check_role


usuarios_bp = Blueprint("usuarios", __name__, url_prefix="/usuarios")

def load_usuario(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        usuarioId = request.view_args.get('id')
        usuario = Usuario.query.get_or_404(usuarioId)
        kwargs["usuario"] = usuario
        return f(*args, **kwargs)

    return decorated_function

@usuarios_bp.route("/")
def list_usuarios():
    usuarios = Usuario.query.all()
    return render_template("usuarios/list.html", usuarios=usuarios)


@usuarios_bp.route("/new")
def new_usuario():
    return render_template("usuarios/new.html")


@usuarios_bp.route("/", methods=["POST"])
def create_usuario():
    username = request.form.get("username")
    email = request.form.get("email")
    password = request.form.get("password_hash")
    role = request.form.get("role")

    nuevo_usuario = Usuario(
    username=username,
    email=email,
    password_hash=generate_password_hash(password),
    role=role,
    )

    db.session.add(nuevo_usuario)
    db.session.commit()

    return redirect(url_for("usuarios.list_usuarios"))

@usuarios_bp.route("/<string:id>")
@load_usuario
def show_usuario(id, usuario):
    return render_template("usuarios/show.html", usuario=usuario)

@usuarios_bp.route("/<string:id>/edit")
@load_usuario
def edit_usuario(id, usuario):
    return render_template("usuarios/edit.html", usuario=usuario)

@usuarios_bp.route("/<string:id>", methods=["POST"])
@load_usuario
def update_usuario(id, usuario):

    usuario.username = request.form["username"]
    usuario.email = request.form["email"]
    usuario.password_hash = generate_password_hash(request.form["password_hash"])
    usuario.role = request.form["role"]

    db.session.commit()

    return redirect(url_for("usuarios.list_usuarios"))

@usuarios_bp.route("/<string:id>", methods=["DELETE"])
@load_usuario
def delete_usuario(id, usuario):
    from models import Objeto
    Objeto.query.filter_by(user_id=usuario.id).delete() #borrar los objetos asociados al usuario antes
    db.session.delete(usuario)
    db.session.commit()

    return redirect(url_for("usuarios.list_usuarios"))

@usuarios_bp.before_request
@check_session
@check_role
def before_request_users():
    pass

