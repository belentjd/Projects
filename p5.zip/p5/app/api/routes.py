from flask import jsonify, request
from database import db
from . import api_v1
from models import Objeto
from .v1.dto import ObjetoDTO, CreateObjetoDTO
from services.external_api import get_location
import asyncio
from logger import logger


@api_v1.route("/objetos", methods=["GET"])
def get_objetos():

    logger.info("GET /objetos - Fetching all objetos")

    objetos = Objeto.query.all()

    result = [
        ObjetoDTO.model_validate(o).model_dump()
        for o in objetos
    ]

    logger.info(f"GET /objetos - Returned {len(result)} objetos")

    return jsonify(result)

@api_v1.route("/objetos/<int:id>", methods=["GET"])
def get_objeto(id):

    logger.info(f"GET /objetos/{id} - Fetching objeto")

    objeto = Objeto.query.get_or_404(id)

    result = ObjetoDTO.model_validate(objeto).model_dump()

    try:
        logger.info("Calling external API for location")
        location = asyncio.run(get_location(lugar=objeto.lugar))
    except Exception as e:
        logger.error(f"Error fetching location: {str(e)}")
        location = None

    result["location_info"] = location

    return jsonify(result)

@api_v1.route("/objetos", methods=["POST"])
def create_objeto():

    body = request.get_json()

    try:
        data = CreateObjetoDTO.model_validate(body)
    except Exception as e:
        logger.error(f"Validation error: {str(e)}")
        return jsonify({"error": "Invalid data"}), 400

    objeto = Objeto(
        nombre=data.nombre,
        descripcion=data.descripcion,
        lugar= data.lugar,
        fecha=data.fecha,
        filename=data.filename
    )

    db.session.add(objeto)
    db.session.commit()

    logger.info(f"POST /objetos - Objeto creado con id={objeto.id}")

    return jsonify(ObjetoDTO.model_validate(objeto).model_dump()), 201

@api_v1.route("/objetos/<int:id>", methods=["PUT"])
def update_objeto(id):

    objeto = Objeto.query.get_or_404(id)

    body = request.get_json()

    try:
        data = CreateObjetoDTO.model_validate(body)
    except Exception as e:
        logger.error(f"Validation error: {str(e)}")
        return jsonify({"error": "Invalid data"}), 400

    objeto.nombre = data.nombre
    objeto.descripcion = data.descripcion
    objeto.lugar = data.lugar
    objeto.fecha = data.fecha
    objeto.filename = data.filename

    db.session.commit()

    logger.info(f"PUT /objetos/{id} - Updating objeto")

    return jsonify({"message": "Objeto actualizado"})

@api_v1.route("/objetos/<int:id>", methods=["DELETE"])
def delete_objeto(id):

    objeto = Objeto.query.get_or_404(id)

    db.session.delete(objeto)
    db.session.commit()

    logger.info(f"DELETE /objetos/{id} - Deleting objeto")  

    return jsonify({"message": "Objeto eliminado"})