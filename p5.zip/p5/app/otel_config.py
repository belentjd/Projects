from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
from opentelemetry.instrumentation.logging import LoggingInstrumentor
from opentelemetry.sdk.resources import Resource

# 1. Definimos el nombre del servicio para identificarlo en Jaeger
resource = Resource.create({"service.name": "objetos-backend"})
provider = TracerProvider(resource=resource)

# 2. Configuramos el exportador hacia Jaeger (puerto gRPC 4317)
otlp_exporter = OTLPSpanExporter(endpoint="http://localhost:4317", insecure=True)
provider.add_span_processor(BatchSpanProcessor(otlp_exporter))
trace.set_tracer_provider(provider)

# 3. Instrumentamos el logging para que inyecte automáticamente los IDs
LoggingInstrumentor().instrument(set_logging_format=False)