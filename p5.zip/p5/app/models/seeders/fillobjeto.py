from database import db
from models import Objeto  # Import your models

def seedObjeto(admin, user):
    # Example seeding for Objeto model
    ob1 = Objeto(nombre='Mochila Azul', 
                 descripcion= "Color azul oscuro, marca Nike, con apuntes dentro.", 
                 fecha= "2025-10-10", 
                 lugar= "Madrid", 
                 filename= "mochila.jpg",
                 user_id=admin.id)
    ob2 = Objeto(nombre='Llaves', 
                 descripcion= "Un poco oxidadas, encontradas junto a su llavero.", 
                 fecha= "2025-10-08", 
                 lugar= "Madrid", 
                 filename= "llaves.jpg",
                 user_id=admin.id)
    db.session.add(ob1)
    db.session.add(ob2)
    db.session.commit()

    print("Objeto data inserted successfully.")