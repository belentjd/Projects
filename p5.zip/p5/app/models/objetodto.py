from typing import Optional
from pydantic import BaseModel

class ObjetoDTO(BaseModel):
    id: int
    nombre: str
    descripcion: str
    fecha:  str
    lugar: str = True
    filename: Optional[str] = None
    user_id: str