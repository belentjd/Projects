import httpx
import asyncio

URL_BASE = "http://127.0.0.1:3000"
URL_BASE_API = f"{URL_BASE}/api/v1"

async def get_objetos():
    url_objetos = f"{URL_BASE_API}/objetos/"
    async with httpx.AsyncClient() as client:
        try:
            response = await client.get(url_objetos)
            response.raise_for_status() # Comprueba si hay errores HTTP (4xx, 5xx)
            objetos = response.json()
            print("Lista de objetos recuperada con éxito.")
            return objetos
        except httpx.HTTPStatusError as exc:
            print(f"Error del servidor ({exc.response.status_code}) al pedir objetos.")
        except httpx.RequestError as exc:
            print(f"Error de red conectando a {exc.request.url}")

async def get_objeto_by_id(objeto_id: int = 1):
    url_objeto = f"{URL_BASE_API}/objetos/{objeto_id}"
    async with httpx.AsyncClient() as client:
        try:
            response = await client.get(url_objeto)
            response.raise_for_status()
            objeto = response.json()
            print(f"Objeto {objeto_id} recuperada con éxito.")
            return objeto
        except httpx.HTTPStatusError as exc:
            if exc.response.status_code == 404:
                print(f"La objeto con ID {objeto_id} no existe en la base de datos.")
            else:
                print(f"Error HTTP {exc.response.status_code}.")
        except httpx.RequestError as exc:
            print(f" Error de red: {exc}")

async def create_objeto(new_objeto: dict):
    url_objeto = f"{URL_BASE_API}/objetos/"
    async with httpx.AsyncClient() as client:
        try:
            # Enviamos el diccionario como payload JSON
            response = await client.post(url_objeto, json=new_objeto)
            response.raise_for_status()
            objeto = response.json()
            print("Nuevo objeto creada correctamente.")
            return objeto
        except httpx.HTTPStatusError as exc:
            print(f"Error al crear objeto. El servidor rechazó los datos ({exc.response.status_code}).")
            # Muy útil para ver qué validación falló en Pydantic en el backend
            print(f"Detalle del servidor: {exc.response.json()}")
        except httpx.RequestError as exc:
            print(f"Error de red: {exc}")

# Agrupamos la ejecución asíncrona en una función main
async def main():
    print("--- Obteniendo todas las vías ---")
    await get_objetos()

    print("\n--- Obteniendo una vía específica ---")
    await get_objetos(1)

    print("\n--- Forzando un error (vía que no existe) ---")
    await get_objeto_by_id(9999)

    print("\n--- Creando una vía nueva ---")
    await create_objeto({
        "nombre": "Laptop",
        "descripcion": "Color gris, grande.", 
        "fecha": "2025-12-10", 
        "lugar": "Barcelona", 
        "filename": "laptop.jpg",
        "user_id": "d3a47de0-fb7b-475f-ac60-3399454bb0ca"
    })

if __name__ == '__main__':
    # asyncio.run arranca el bucle de eventos (Event Loop) que maneja las funciones async
    asyncio.run(main())