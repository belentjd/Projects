from urllib.parse import parse_qs
from io import BytesIO

class MethodOverrideMiddleware:
    allowed_methods = {'GET', 'POST', 'PUT', 'DELETE', 'PATCH'}

    def __init__(self, app):
        self.app = app

    def __call__(self, environ, start_response):
        if environ['REQUEST_METHOD'] == 'POST' and \
            environ.get('CONTENT_TYPE','').startswith('application/x-www-form-urlencoded'):
            try:
                request_body_size = int(environ.get('CONTENT_LENGTH', 0))
            except (ValueError):
                request_body_size = 0


            request_body = environ['wsgi.input'].read(request_body_size)
            environ['wsgi.input'] = BytesIO(request_body)
            form_data = parse_qs(request_body.decode())

            method = form_data.get('_method', [''])[0].upper()
            if method in self.allowed_methods:
                environ['REQUEST_METHOD'] = method

        return self.app(environ, start_response)