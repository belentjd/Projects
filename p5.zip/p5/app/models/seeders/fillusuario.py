from database import db
from models import Usuario  # Import your models
from werkzeug.security import generate_password_hash

def seedUsuario():
    # Example seeding for Usuario model
    admin = Usuario(username='belentjd', 
                 email= "belen@gmail.com", 
                 password_hash= generate_password_hash("ABCD"), 
                 role= "admin", 
                 )
    user = Usuario(username='pepito', 
                 email= "pepito@gmail.com", 
                 password_hash= generate_password_hash("EFGH"), 
                 role= "user", 
                 )
    db.session.add(admin)
    db.session.add(user)
    db.session.commit()

    print("Usuario data inserted successfully.")

    return admin, user